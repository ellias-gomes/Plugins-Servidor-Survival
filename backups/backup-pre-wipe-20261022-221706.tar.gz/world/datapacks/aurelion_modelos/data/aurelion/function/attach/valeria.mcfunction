tag @s add aur_base
scoreboard players add #next aur_id 1
scoreboard players operation @s aur_id = #next aur_id
scoreboard players set @s aur_model 9
scoreboard players set @s aur_ph 0
scoreboard players set @s aur_cyc 0
scoreboard players set @s aur_hold 0
scoreboard players set @s aur_anim 0
scoreboard players set @s aur_px 0
scoreboard players set @s aur_pz 0
effect give @s minecraft:invisibility infinite 0 true
attribute @s minecraft:scale base set 1.5
item replace entity @s weapon.mainhand with minecraft:air
item replace entity @s weapon.offhand with minecraft:air
bossbar add aurelion:semi_4 "§5§l🗡 Valeria, a Lâmina Sombria §7[Caçada]"
bossbar set aurelion:semi_4 color purple
bossbar set aurelion:semi_4 style notched_6
bossbar set aurelion:semi_4 name "§5§l🗡 Valeria, a Lâmina Sombria §7[Caçada]"
bossbar set aurelion:semi_4 visible true
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_torso"],block_state:"minecraft:black_concrete",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[-0.5000f,1.4000f,-0.3000f],scale:[1.0000f,1.2000f,0.6000f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f}
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_cinto"],block_state:"minecraft:purple_concrete",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[-0.5250f,1.3500f,-0.3250f],scale:[1.0500f,0.2000f,0.6500f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f}
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_head"],block_state:"minecraft:black_concrete",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[-0.3500f,2.6500f,-0.3500f],scale:[0.7000f,0.7000f,0.7000f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f}
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_olho_l"],block_state:"minecraft:crying_obsidian",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[-0.2500f,3.0000f,0.3350f],scale:[0.1400f,0.1000f,0.0500f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f,brightness:{block:15,sky:15}}
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_olho_r"],block_state:"minecraft:crying_obsidian",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.1100f,3.0000f,0.3350f],scale:[0.1400f,0.1000f,0.0500f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f,brightness:{block:15,sky:15}}
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_braco_l"],block_state:"minecraft:black_concrete",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[-0.9100f,1.3500f,-0.1900f],scale:[0.3800f,1.2000f,0.3800f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f}
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_manopla_l"],block_state:"minecraft:purple_concrete",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[-0.9400f,1.2750f,-0.2200f],scale:[0.4400f,0.3500f,0.4400f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f}
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_perna_l"],block_state:"minecraft:black_concrete",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[-0.4900f,0.0000f,-0.2300f],scale:[0.4200f,1.4000f,0.4600f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f}
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_braco_r"],block_state:"minecraft:black_concrete",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.5300f,1.3500f,-0.1900f],scale:[0.3800f,1.2000f,0.3800f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f}
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_manopla_r"],block_state:"minecraft:purple_concrete",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.5000f,1.2750f,-0.2200f],scale:[0.4400f,0.3500f,0.4400f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f}
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_perna_r"],block_state:"minecraft:black_concrete",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.0700f,0.0000f,-0.2300f],scale:[0.4200f,1.4000f,0.4600f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f}
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_capa"],block_state:"minecraft:black_wool",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[-0.5500f,0.8500f,-0.4400f],scale:[1.1000f,2.1000f,0.1200f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f}
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_lamina_l"],block_state:"minecraft:crying_obsidian",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[-0.7700f,0.5000f,0.4900f],scale:[0.1000f,1.6000f,0.1200f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f,brightness:{block:15,sky:15}}
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_lamina_r"],block_state:"minecraft:crying_obsidian",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.6700f,0.5000f,0.4900f],scale:[0.1000f,1.6000f,0.1200f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f,brightness:{block:15,sky:15}}
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_guarda_l"],block_state:"minecraft:amethyst_block",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[-0.9200f,1.5000f,0.3500f],scale:[0.4000f,0.1000f,0.1000f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f}
summon minecraft:block_display ~ ~ ~ {Tags:["aur_part","aur_new","aur_valeria_guarda_r"],block_state:"minecraft:amethyst_block",transformation:{left_rotation:[0.0000f,0.0000f,0.0000f,1.0000f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.5200f,1.5000f,0.3500f],scale:[0.4000f,0.1000f,0.1000f]},teleport_duration:2,interpolation_duration:0,view_range:2.0f}
execute as @e[tag=aur_new,distance=..3] run function aurelion:attach_fin
